const FIREBASE_CONFIG = {
  apiKey: "AIzaSyBTZX-pnDH0RKSi5K0CQftzW7QFh4LgUv8",
  authDomain: "kantong-doraemon-570d6.firebaseapp.com",
  projectId: "kantong-doraemon-570d6",
  storageBucket: "kantong-doraemon-570d6.firebasestorage.app",
  messagingSenderId: "314014972914",
  appId: "1:314014972914:web:d37b40774fbc91d17c896b",
};

const SYNC_KEY = "STFoEzG0uY_Ixow0Pqr9h-Lp1cr7Z2A1C-fdpljFqys";