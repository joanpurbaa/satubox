const STORE_KEY = "sb_session";
const IDP_URL =
  "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" +
  FIREBASE_CONFIG.apiKey;

const $ = (id) => document.getElementById(id);
const loginView = $("view-login");
const mainView = $("view-main");
const statusEl = $("status");
const listEl = $("list");
const nameInput = $("site-name");

let session = null;
let db = null;
let listener = null;

const chromeCall = (fnName, ...args) =>
  new Promise((resolve, reject) => {
    try {
      const parts = fnName.split(".");
      let obj = chrome;
      for (let i = 0; i < parts.length - 1; i++) obj = obj[parts[i]];
      const fn = obj[parts[parts.length - 1]];
      const r = fn.apply(obj, args);
      if (r && typeof r.then === "function") r.then(resolve, reject);
      else resolve(r);
    } catch (e) {
      reject(e);
    }
  });

/* ---------- sesi ---------- */

async function getStoredSession() {
  const data = await chromeCall("storage.local.get", STORE_KEY);
  return data[STORE_KEY] || null;
}

async function saveStoreSession(next) {
  await chromeCall("storage.local.set", { [STORE_KEY]: next });
}

async function clearStoredSession() {
  await chromeCall("storage.local.remove", STORE_KEY);
}

async function loginWithREST(email, password) {
  let res;
  try {
    res = await fetch(IDP_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    });
  } catch (e) {
    return { ok: false, error: "Gagal terhubung ke server, coba lagi." };
  }
  const data = await res.json();
  if (!res.ok || !data.idToken) {
    const msg = (data.error && data.error.message) || "";
    if (/INVALID_LOGIN_CREDENTIALS|EMAIL_NOT_FOUND|INVALID_PASSWORD|USER_NOT_FOUND/.test(msg)) {
      return { ok: false, error: "Email atau password salah." };
    }
    return { ok: false, error: "Login gagal, coba beberapa saat lagi." };
  }
  return {
    ok: true,
    idToken: data.idToken,
    email: data.email,
    uid: data.localId,
  };
}

function showLogin() {
  mainView.hidden = true;
  loginView.hidden = false;
  $("login-error").textContent = "";
  $("login-email").focus();
}

function showMain() {
  loginView.hidden = true;
  mainView.hidden = false;
  const email = session ? session.email : "";
  $("acc-email").textContent = email;
  const initial = (email || "S").charAt(0).toUpperCase();
  $("acc-avatar").textContent = initial;
}

function flash(text) {
  statusEl.textContent = text || "";
}

/* ---------- firestore (mode lama, lockers yang sama) ---------- */

function firebaseReady() {
  return !!(FIREBASE_CONFIG && FIREBASE_CONFIG.apiKey && FIREBASE_CONFIG.apiKey.indexOf("ISI_") !== 0);
}

function initDb() {
  if (!firebaseReady()) return false;
  if (!db) {
    firebase.initializeApp(FIREBASE_CONFIG);
    db = firebase.firestore();
    db.settings({ ignoreUndefinedProperties: true });
  }
  return true;
}

function sitesRef() {
  return db.collection("lockers").doc(SYNC_KEY).collection("sites");
}

/* ---------- baca cookie ---------- */

function getActiveTab() {
  return chromeCall("tabs.query", { active: true, currentWindow: true }).then(
    (tabs) => (tabs && tabs[0] ? tabs[0] : null),
  );
}

function domainRoot(raw) {
  let d = (raw || "").trim().toLowerCase();
  if (!d) return "";
  try {
    if (d.includes("://") || d.startsWith("www.")) {
      d = new URL(d.includes("://") ? d : "https://" + d).hostname;
    }
  } catch (e) {}
  d = d.replace(/^\.+/, "").replace(/:\d+$/, "");
  const parts = d.split(".");
  if (parts.length >= 3) d = parts.slice(-2).join(".");
  return d.replace(/www\./g, "");
}

function mapCookie(c) {
  return {
    name: c.name,
    value: c.value,
    domain: c.domain,
    hostOnly: c.hostOnly,
    path: c.path,
    expires: c.expirationDate || -1,
    httpOnly: c.httpOnly,
    secure: c.secure,
    session: !c.expirationDate,
    sameSite: c.sameSite === "unspecified" ? "no_restriction" : c.sameSite,
  };
}

const COMPANION_DOMAINS = {
  "chatgpt.com": ["openai.com", "chat.openai.com"],
  "openai.com": ["chatgpt.com", "chat.openai.com"],
  "chat.openai.com": ["openai.com", "chatgpt.com"],
};

async function collectCookies(dom) {
  const seen = new Set();
  const out = [];
  const targets = [dom].concat(COMPANION_DOMAINS[dom] || []);
  for (const target of targets) {
    for (const f of [target, "." + target]) {
      const rows = await chromeCall("cookies.getAll", { domain: f });
      for (const c of rows) {
        const key = c.domain + "|" + c.path + "|" + c.name;
        if (!seen.has(key)) {
          seen.add(key);
          out.push(mapCookie(c));
        }
      }
    }
  }
  out.sort((a, b) => a.name.localeCompare(b.name));
  return out;
}

/* ---------- aksi ---------- */

async function pullFromTab() {
  if (!session) return;
  if (!initDb()) {
    flash("Firebase belum dikonfigurasi.");
    return;
  }
  flash("Mengambil cookie dari tab aktif...");
  let tab = null;
  try {
    tab = await getActiveTab();
  } catch (e) {
    flash("ERROR: " + e.message);
    return;
  }
  if (!tab || !tab.url || !/^https?:\/\//.test(tab.url)) {
    flash("Tidak ada tab aktif yang valid. Buka situs yang sudah login dulu.");
    return;
  }
  const dom = domainRoot(new URL(tab.url).hostname);
  if (!dom) {
    flash("Gagal membaca domain tab aktif.");
    return;
  }
  try {
    const cookies = await collectCookies(dom);
    if (!cookies.length) {
      flash("0 cookie ditemukan untuk " + dom + ". Pastikan kamu sudah login di situs itu.");
      return;
    }
    const name = (nameInput.value || "").trim() || tab.url.replace("https://", "").replace("http://", "");
    await sitesRef().doc(dom).set({
      domain: dom,
      name,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
      cookies,
    });
    nameInput.value = "";
    const names = cookies.map((c) => c.name).join(", ");
    let msg = cookies.length + " cookie untuk " + dom + " tersimpan. Key cookies: " + names;
    if (/chatgpt|openai/.test(dom)) {
      msg += " [OpenAI biasanya tolak sesi lintas browser karena fingerprint device]";
    }
    flash(msg);
  } catch (e) {
    console.error(e);
    flash("ERROR: " + e.message);
  }
}

const EXTEND_DAYS = 365;

function extendCookieExpiry(originalExpiry) {
  const nowSeconds = Math.floor(Date.now() / 1000);
  const minExpiry = nowSeconds + EXTEND_DAYS * 86400;
  if (!originalExpiry || originalExpiry <= 0) return minExpiry;
  return Math.max(originalExpiry, minExpiry);
}

async function injectAndOpen(site) {
  if (!db || !site.cookies || !session) return;
  const base = "https://" + site.domain.replace(/^\./, "");
  let ok = 0;
  let fail = 0;
  for (const c of site.cookies) {
    try {
      const host = (c.domain || site.domain).replace(/^\./, "");
      const url = "https://" + host + (c.path || "/");
      await chromeCall("cookies.set", {
        url,
        name: c.name,
        value: c.value,
        path: c.path || "/",
        secure: !!c.secure,
        httpOnly: !!c.httpOnly,
        domain: c.domain,
        expirationDate: extendCookieExpiry(typeof c.expirationDate === "number" ? c.expirationDate : -1),
      });
      ok++;
    } catch (e) {
      fail++;
    }
  }
  flash(ok + "/" + site.cookies.length + " cookie disuntik" + (fail ? " (" + fail + " gagal)" : "") + ". Membuka " + site.domain + "...");
  await chromeCall("tabs.create", { url: base + "/" });
}

function renderList(sites) {
  listEl.innerHTML = "";
  const entries = Object.keys(sites).map((id) => ({ id, ...sites[id] }));
  if (!entries.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Belum ada cookie tersimpan. Buka situs yang sudah login lalu klik \"Tarik\".";
    listEl.appendChild(empty);
    return;
  }
  entries.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  for (const s of entries) {
    const item = document.createElement("div");
    item.className = "item";

    const row1 = document.createElement("div");
    row1.className = "row1";
    const nameEl = document.createElement("span");
    nameEl.className = "name";
    nameEl.textContent = s.name || s.domain;
    row1.appendChild(nameEl);
    const cnt = document.createElement("span");
    cnt.className = "meta";
    cnt.textContent = (s.cookies ? s.cookies.length : 0) + " cookie";
    row1.appendChild(cnt);

    const meta = document.createElement("div");
    meta.className = "meta";
    const t = s.updatedAt ? new Date(s.updatedAt.seconds ? s.updatedAt.seconds * 1000 : s.updatedAt).toLocaleString() : "";
    meta.textContent = s.domain + (t ? " | " + t : "");

    const btnRow = document.createElement("div");
    btnRow.className = "btn-row";
    const openBtn = document.createElement("button");
    openBtn.textContent = "Buka";
    openBtn.addEventListener("click", () => injectAndOpen(s));
    const delBtn = document.createElement("button");
    delBtn.className = "danger";
    delBtn.textContent = "Hapus";
    delBtn.addEventListener("click", async () => {
      try {
        await sitesRef().doc(s.id).delete();
        flash(s.domain + " dihapus.");
      } catch (e) {
        flash("ERROR hapus: " + e.message);
      }
    });
    btnRow.appendChild(openBtn);
    btnRow.appendChild(delBtn);

    item.appendChild(row1);
    item.appendChild(meta);
    item.appendChild(btnRow);
    listEl.appendChild(item);
  }
}

function startListener() {
  if (!initDb()) {
    flash("Firebase belum dikonfigurasi.");
    renderList({});
    return;
  }
  flash("Sinkron...");
  if (listener) listener();
  listener = sitesRef().onSnapshot(
    (snap) => {
      const sites = {};
      snap.forEach((d) => {
        sites[d.id] = d.data();
      });
      renderList(sites);
      flash(Object.keys(sites).length + " app tersedia (realtime).");
    },
    (err) => {
      console.error(err);
      flash("Gagal tersambung Firestore: " + err.message);
    }
  );
}

function enterApp() {
  if (!session) return;
  showMain();
  if (!initDb()) {
    flash("Firebase belum dikonfigurasi. Isi config.js dulu.");
    return;
  }
  getActiveTab().then((tab) => {
    if (tab && tab.url && /^https?:\/\//.test(tab.url)) {
      const host = new URL(tab.url).hostname.replace(/^www\./, "");
      if (!nameInput.value) nameInput.value = host;
    }
  });
  startListener();
}

async function onLoginSubmit(e) {
  e.preventDefault();
  const email = $("login-email").value.trim();
  const password = $("login-password").value;
  const errEl = $("login-error");
  errEl.textContent = "";

  if (!email || !password) {
    errEl.textContent = "Email dan password wajib diisi.";
    return;
  }

  const btn = $("login-submit");
  btn.disabled = true;
  btn.textContent = "Memproses…";

  const res = await loginWithREST(email, password);
  if (!res.ok) {
    errEl.textContent = res.error || "Login gagal.";
    btn.disabled = false;
    btn.textContent = "Masuk";
    return;
  }

  session = { idToken: res.idToken, email: res.email, uid: res.uid };
  await saveStoreSession(session);

  $("login-email").value = "";
  $("login-password").value = "";
  btn.disabled = false;
  btn.textContent = "Masuk";

  enterApp();
  flash("Halo, " + (res.email || "") + "!");
}

async function onLogout() {
  if (listener) {
    listener();
    listener = null;
  }
  await clearStoredSession();
  session = null;
  showLogin();
}

/* ---------- init ---------- */

$("login-form").addEventListener("submit", onLoginSubmit);
$("logout-btn").addEventListener("click", onLogout);
$("pull-btn").addEventListener("click", pullFromTab);

document.addEventListener("DOMContentLoaded", () => {
  getStoredSession().then((stored) => {
    if (stored && stored.idToken) {
      session = stored;
      enterApp();
    } else {
      showLogin();
    }
  });
});