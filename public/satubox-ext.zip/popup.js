const STORE_KEY = "sb_session";
const EXPIRY_KEY = "sb_expiry";
const SITES_KEY = "sb_sites";
const CATALOG_KEY = "sb_catalog";
const IDP_URL =
  "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" +
  FIREBASE_CONFIG.apiKey;

const ICON_MAP = {
  "capcut.com": "capcut.webp",
  "hbomax.com": "hbomax.webp",
  "primevideo.com": "prime.webp",
  "netflix.com": "netflix.webp",
  "youtube.com": "youtube.webp",
  "openai.com": "chatgpt.webp",
  "chatgpt.com": "chatgpt.webp",
  "chat.openai.com": "chatgpt.webp",
  "spotify.com": "spotify.webp",
  "canva.com": "canva.webp",
  "disneyplus.com": "disney.webp",
  "viu.com": "viu.webp",
  "vidio.com": "vidio.webp",
  "wetv.vip": "wetv.webp",
  "iqiyi.com": "iqiyi.webp",
  "youku.com": "youku.webp",
  "bilibili.com": "bstation.webp",
  "microsoft.com": "microsoft.webp",
  "office.com": "microsoft.webp",
  "microsoft365.com": "microsoft.webp",
  "grammarly.com": "grammarly.webp",
  "deepl.com": "deepl.webp",
  "quillbot.com": "quillbot.webp",
  "scribd.com": "scribd.webp",
  "ilovepdf.com": "ilovepdf.webp",
  "camscanner.com": "camscanner.webp",
  "picsart.com": "picsart.webp",
  "remini.ai": "remini.webp",
  "alightcreative.com": "alight-motion.webp",
  "crunchyroll.com": "crunchyroll.webp",
  "loklok.com": "loklok.webp",
  "music.apple.com": "apple-music.webp",
  "tv.apple.com": "apple-tv.webp",
  "duolingo.com": "duolingo.webp",
  "wps.cn": "wps-office.webp",
  "wps.com": "wps-office.webp",
};

const CATEGORY_MAP = {
  "netflix.com": "STREAMING",
  "primevideo.com": "STREAMING",
  "youtube.com": "STREAMING",
  "crunchyroll.com": "STREAMING",
  "vidio.com": "STREAMING",
  "disneyplus.com": "STREAMING",
  "bilibili.com": "STREAMING",
  "hbomax.com": "STREAMING",
  "viu.com": "STREAMING",
  "tv.apple.com": "STREAMING",
  "wetv.vip": "STREAMING",
  "loklok.com": "STREAMING",
  "iqiyi.com": "STREAMING",
  "youku.com": "STREAMING",
  "spotify.com": "MUSIK",
  "music.apple.com": "MUSIK",
  "canva.com": "KREATIF",
  "capcut.com": "KREATIF",
  "alightcreative.com": "KREATIF",
  "picsart.com": "KREATIF",
  "remini.ai": "KREATIF",
  "openai.com": "PRODUKTIVITAS",
  "chatgpt.com": "PRODUKTIVITAS",
  "chat.openai.com": "PRODUKTIVITAS",
  "grammarly.com": "PRODUKTIVITAS",
  "wps.cn": "PRODUKTIVITAS",
  "wps.com": "PRODUKTIVITAS",
  "microsoft.com": "PRODUKTIVITAS",
  "office.com": "PRODUKTIVITAS",
  "microsoft365.com": "PRODUKTIVITAS",
  "camscanner.com": "PRODUKTIVITAS",
  "deepl.com": "PRODUKTIVITAS",
  "ilovepdf.com": "PRODUKTIVITAS",
  "quillbot.com": "PRODUKTIVITAS",
  "scribd.com": "PRODUKTIVITAS",
  "duolingo.com": "PENDIDIKAN",
};

const CATEGORY_ORDER = ["Semua", "STREAMING", "MUSIK", "KREATIF", "PRODUKTIVITAS", "PENDIDIKAN", "Lainnya"];

const MONTHS = ["JAN", "FEB", "MAR", "APR", "MEI", "JUN", "JUL", "AGU", "SEP", "OKT", "NOV", "DES"];

function remoteMeta(domain) {
  if (!remoteCatalog || !domain) return null;
  const d = normalizedDomain(domain);
  return remoteCatalog.find((x) => x.domain === d) || null;
}

async function loadCatalog() {
  let res;
  try {
    res = await fetch(API_BASE + "/api/ext/apps");
  } catch (e) {
    res = null;
  }
  if (res && res.ok) {
    const body = await res.json().catch(() => null);
    if (body && body.ok && Array.isArray(body.apps)) {
      remoteCatalog = body.apps;
      await chromeCall("storage.local.set", {
        [CATALOG_KEY]: { items: remoteCatalog, checkedAt: Date.now() },
      });
      return;
    }
  }
  const cached = await chromeCall("storage.local.get", CATALOG_KEY);
  const data = cached && cached[CATALOG_KEY];
  if (data && Array.isArray(data.items)) {
    remoteCatalog = data.items;
  }
}

function iconFor(domain) {
  if (!domain) return "";
  const d = normalizedDomain(domain);
  const r = remoteMeta(d);
  if (r && r.icon) return "/" + String(r.icon).replace(/^\/+/, "");
  if (ICON_MAP[d]) return ICON_MAP[d];
  const match = Object.keys(ICON_MAP).find((key) => d.endsWith("." + key));
  return match ? ICON_MAP[match] : "";
}

function categoryOf(domain) {
  const d = normalizedDomain(domain);
  const r = remoteMeta(d);
  if (r && r.cat) return r.cat;
  if (CATEGORY_MAP[d]) return CATEGORY_MAP[d];
  const match = Object.keys(CATEGORY_MAP).find((key) => d.endsWith("." + key));
  return match ? CATEGORY_MAP[match] : "Lainnya";
}

function isAdminAccount() {
  return !!(session && session.isAdmin && ADMIN_EMAIL && session.email === ADMIN_EMAIL);
}

const $ = (id) => document.getElementById(id);
const loginView = $("view-login");
const mainView = $("view-main");
const statusEl = $("status");
const nameInput = $("site-name");
const adminPullEl = $("admin-pull");
const lockOverlay = $("lock-overlay");
const accUsernameEl = $("acc-username");
const accEmailEl = $("acc-email");
const expPlanEl = $("exp-plan");
const expDateEl = $("exp-date");
const catEl = $("cat-wrap");
const gridEl = $("grid");

let session = null;
let db = null;
let listener = null;
let expiryCache = null;
let revoked = false;
let latestDomains = [];
let remoteCatalog = null;
let currentSites = {};
let activeCat = "Semua";

const chromeCall = (fnName, ...args) =>
  new Promise((resolve, reject) => {
    try {
      const parts = fnName.split(".");
      let obj = chrome;
      for (let i = 0; i < parts.length - 1; i++) obj = obj[parts[i]];
      const fn = obj[parts[parts.length - 1]];
      const r = fn.apply(obj, args);
      if (r && typeof r.then === "function") r.then(resolve, reject);
      else resolve(r);
    } catch (e) {
      reject(e);
    }
  });

/* ---------- sesi ---------- */

async function getStoredSession() {
  const data = await chromeCall("storage.local.get", STORE_KEY);
  return data[STORE_KEY] || null;
}

async function saveStoreSession(next) {
  await chromeCall("storage.local.set", { [STORE_KEY]: next });
}

async function clearStoredSession() {
  await chromeCall("storage.local.remove", STORE_KEY);
  await chromeCall("storage.local.remove", EXPIRY_KEY);
}

/* ---------- status langganan ---------- */

async function fetchProfile() {
  if (!session || !session.idToken) return null;
  let res;
  try {
    res = await fetch(API_BASE + "/api/ext/profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ idToken: session.idToken }),
    });
  } catch (e) {
    return null;
  }
  if (!res.ok) return null;
  const data = await res.json().catch(() => null);
  if (!data || !data.ok || typeof data.profile.expiresAtMs !== "number") return null;
  return data.profile;
}

async function loadExpiryCache() {
  const cached = await chromeCall("storage.local.get", EXPIRY_KEY);
  if (cached && typeof cached[EXPIRY_KEY]?.expiresAtMs === "number") {
    expiryCache = cached[EXPIRY_KEY];
  }
}

async function syncExpiry(force) {
  if (!session) return;
  const fresh =
    expiryCache &&
    typeof expiryCache.checkedAt === "number" &&
    Date.now() - expiryCache.checkedAt < 60000;
  if (!force && fresh) {
    renderExpiry();
    return;
  }
  const profile = await fetchProfile();
  if (profile) {
    expiryCache = {
      expiresAtMs: profile.expiresAtMs,
      checkedAt: Date.now(),
      username: profile.username,
      planLabel: profile.planLabel,
    };
    await chromeCall("storage.local.set", { [EXPIRY_KEY]: expiryCache });
  }
  renderExpiry();
}

function isExpiredNow() {
  if (isAdminAccount()) return false;
  return !!expiryCache && expiryCache.expiresAtMs <= Date.now();
}

function fmtDate(ms) {
  const d = new Date(ms);
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return dd + " " + MONTHS[d.getMonth()] + " " + d.getFullYear() + " · " + hh + ":" + mm;
}

function renderExpiry() {
  if (!session) return;
  if (isAdminAccount()) {
    expDateEl.textContent = "Aktif tanpa batas";
    expPlanEl.textContent = "ADMIN";
    expPlanEl.hidden = false;
    return;
  }
  if (!expiryCache) {
    expDateEl.textContent = "Memeriksa status…";
    expPlanEl.hidden = true;
    return;
  }
  expDateEl.textContent = fmtDate(expiryCache.expiresAtMs);
  expPlanEl.textContent = expiryCache.planLabel || "";
  expPlanEl.hidden = !expiryCache.planLabel;
}

function cookieCleanseUrl(c) {
  const host = (c.domain || "").replace(/^\./, "");
  return "https://" + host + (c.path || "/");
}

async function revokePlatformCookies() {
  const targets = latestDomains.length
    ? latestDomains
    : (((await chromeCall("storage.local.get", SITES_KEY))[SITES_KEY]) || []);
  const hosts = [...new Set(targets.flatMap((d) => [d, "." + d]))];
  let removed = 0;
  for (const h of hosts) {
    let rows = [];
    try {
      rows = await chromeCall("cookies.getAll", { domain: h });
    } catch (e) {
      continue;
    }
    for (const c of rows) {
      try {
        await chromeCall("cookies.remove", { url: cookieCleanseUrl(c), name: c.name });
        removed++;
      } catch (e) {}
    }
  }
  console.info("[SatuBox] cookie platform premium dihapus:", removed);
}

function updateLock() {
  if (!session || !lockOverlay) return;
  const expired = isExpiredNow();
  lockOverlay.hidden = !expired;
  if (expired && !revoked) {
    revoked = true;
    revokePlatformCookies();
  }
}

/* ---------- tampilan ---------- */

function showLogin() {
  mainView.hidden = true;
  loginView.hidden = false;
  $("login-error").textContent = "";
  $("login-email").focus();
}

function showMain() {
  loginView.hidden = true;
  mainView.hidden = false;
  const email = session ? session.email : "";
  const username =
    (expiryCache && expiryCache.username) || String(email || "").split("@")[0] || "";
  accUsernameEl.textContent = username;
  accEmailEl.textContent = email;
  adminPullEl.hidden = !isAdminAccount();
}

function flash(text) {
  statusEl.textContent = text || "";
}

/* ---------- firestore (mode lama, lockers yang sama) ---------- */

function firebaseReady() {
  return !!(FIREBASE_CONFIG && FIREBASE_CONFIG.apiKey && FIREBASE_CONFIG.apiKey.indexOf("ISI_") !== 0);
}

function initDb() {
  if (!firebaseReady()) return false;
  if (!db) {
    firebase.initializeApp(FIREBASE_CONFIG);
    db = firebase.firestore();
    db.settings({ ignoreUndefinedProperties: true });
  }
  return true;
}

function sitesRef() {
  return db.collection("lockers").doc(SYNC_KEY).collection("sites");
}

/* ---------- baca cookie ---------- */

function getActiveTab() {
  return chromeCall("tabs.query", { active: true, currentWindow: true }).then(
    (tabs) => (tabs && tabs[0] ? tabs[0] : null),
  );
}

function domainRoot(raw) {
  let d = (raw || "").trim().toLowerCase();
  if (!d) return "";
  try {
    if (d.includes("://") || d.startsWith("www.")) {
      d = new URL(d.includes("://") ? d : "https://" + d).hostname;
    }
  } catch (e) {}
  d = d.replace(/^\.+/, "").replace(/:\d+$/, "");
  const parts = d.split(".");
  if (parts.length >= 3) d = parts.slice(-2).join(".");
  return d.replace(/www\./g, "");
}

function mapCookie(c) {
  return {
    name: c.name,
    value: c.value,
    domain: c.domain,
    hostOnly: c.hostOnly,
    path: c.path,
    expires: c.expirationDate || -1,
    httpOnly: c.httpOnly,
    secure: c.secure,
    session: !c.expirationDate,
    sameSite: c.sameSite === "unspecified" ? "no_restriction" : c.sameSite,
  };
}

const COMPANION_DOMAINS = {
  "chatgpt.com": ["openai.com", "chat.openai.com"],
  "openai.com": ["chatgpt.com", "chat.openai.com"],
  "chat.openai.com": ["openai.com", "chatgpt.com"],
};

async function collectCookies(dom) {
  const seen = new Set();
  const out = [];
  const targets = [dom].concat(COMPANION_DOMAINS[dom] || []);
  for (const target of targets) {
    for (const f of [target, "." + target]) {
      const rows = await chromeCall("cookies.getAll", { domain: f });
      for (const c of rows) {
        const key = c.domain + "|" + c.path + "|" + c.name;
        if (!seen.has(key)) {
          seen.add(key);
          out.push(mapCookie(c));
        }
      }
    }
  }
  out.sort((a, b) => a.name.localeCompare(b.name));
  return out;
}

/* ---------- aksi ---------- */

async function pullFromTab() {
  if (!session) return;
  if (isExpiredNow()) {
    flash("Langganan kedaluwarsa. Perpanjang dulu di satubox.id sebelum mengambil cookie.");
    return;
  }
  if (!initDb()) {
    flash("Firebase belum dikonfigurasi.");
    return;
  }
  flash("Mengambil cookie dari tab aktif...");
  let tab = null;
  try {
    tab = await getActiveTab();
  } catch (e) {
    flash("ERROR: " + e.message);
    return;
  }
  if (!tab || !tab.url || !/^https?:\/\//.test(tab.url)) {
    flash("Tidak ada tab aktif yang valid. Buka situs yang sudah login dulu.");
    return;
  }
  const dom = domainRoot(new URL(tab.url).hostname);
  if (!dom) {
    flash("Gagal membaca domain tab aktif.");
    return;
  }
  try {
    const cookies = await collectCookies(dom);
    if (!cookies.length) {
      flash("0 cookie ditemukan untuk " + dom + ". Pastikan kamu sudah login di situs itu.");
      return;
    }
    const name = (nameInput.value || "").trim() || tab.url.replace("https://", "").replace("http://", "");
    await sitesRef().doc(dom).set({
      domain: dom,
      name,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
      cookies,
    });
    nameInput.value = "";
    const names = cookies.map((c) => c.name).join(", ");
    let msg = cookies.length + " cookie untuk " + dom + " tersimpan. Key cookies: " + names;
    if (/chatgpt|openai/.test(dom)) {
      msg += " [OpenAI biasanya tolak sesi lintas browser karena fingerprint device]";
    }
    flash(msg);
  } catch (e) {
    console.error(e);
    flash("ERROR: " + e.message);
  }
}

const EXTEND_DAYS = 365;

function extendCookieExpiry(originalExpiry) {
  const nowSeconds = Math.floor(Date.now() / 1000);
  const minExpiry = nowSeconds + EXTEND_DAYS * 86400;
  if (!originalExpiry || originalExpiry <= 0) return minExpiry;
  return Math.max(originalExpiry, minExpiry);
}

async function injectAndOpen(site) {
  if (!db || !site.cookies || !session) return;
  if (isExpiredNow()) {
    flash("Langganan kedaluwarsa. Perpanjang dulu di satubox.id untuk membuka halaman.");
    return;
  }
  const base = "https://" + site.domain.replace(/^\./, "");
  let ok = 0;
  let fail = 0;
  for (const c of site.cookies) {
    try {
      const host = (c.domain || site.domain).replace(/^\./, "");
      const url = "https://" + host + (c.path || "/");
      await chromeCall("cookies.set", {
        url,
        name: c.name,
        value: c.value,
        path: c.path || "/",
        secure: !!c.secure,
        httpOnly: !!c.httpOnly,
        domain: c.domain,
        expirationDate: extendCookieExpiry(typeof c.expirationDate === "number" ? c.expirationDate : -1),
      });
      ok++;
    } catch (e) {
      fail++;
    }
  }
  flash(ok + "/" + site.cookies.length + " cookie disuntik" + (fail ? " (" + fail + " gagal)" : "") + ". Membuka " + site.domain + "...");
  await chromeCall("tabs.create", { url: base + "/" });
}

/* ---------- daftar aplikasi ---------- */

function buildIcon(container, domain, fallbackLabel) {
  const icon = iconFor(domain);
  const img = document.createElement("img");
  img.alt = "";
  img.loading = "lazy";
  if (icon) {
    img.src = /^https?:\/\//.test(icon)
      ? icon
      : API_BASE + "/" + String(icon).replace(/^\/+/, "");
    img.addEventListener("error", () => {
      img.style.display = "none";
      const fb = container.querySelector(".tile-fb");
      if (fb) fb.style.display = "grid";
    });
  } else {
    img.style.display = "none";
  }
  container.appendChild(img);

  const fb = document.createElement("span");
  fb.className = "tile-fb";
  fb.textContent = String(fallbackLabel || "?").charAt(0).toUpperCase();
  if (icon) fb.style.display = "none";
  container.appendChild(fb);
}

const NAMES_MAP = {
  "capcut.com": "CapCut",
  "hbomax.com": "HBO Max",
  "netflix.com": "Netflix",
  "primevideo.com": "Prime Video",
  "youtube.com": "YouTube",
  "openai.com": "ChatGPT",
  "chatgpt.com": "ChatGPT",
  "chat.openai.com": "ChatGPT",
  "spotify.com": "Spotify",
  "canva.com": "Canva",
  "disneyplus.com": "Disney+",
  "viu.com": "Viu",
  "vidio.com": "Vidio",
  "wetv.vip": "WeTV",
  "iqiyi.com": "iQIYI",
  "youku.com": "Youku",
  "bilibili.com": "Bstation",
  "microsoft.com": "Microsoft",
  "office.com": "Microsoft 365",
  "microsoft365.com": "Microsoft 365",
  "grammarly.com": "Grammarly",
  "deepl.com": "DeepL",
  "quillbot.com": "QuillBot",
  "scribd.com": "Scribd",
  "ilovepdf.com": "iLovePDF",
  "camscanner.com": "CamScanner",
  "picsart.com": "Picsart",
  "remini.ai": "Remini",
  "alightcreative.com": "Alight Motion",
  "crunchyroll.com": "Crunchyroll",
  "loklok.com": "LokLok",
  "music.apple.com": "Apple Music",
  "tv.apple.com": "Apple TV",
  "duolingo.com": "Duolingo",
  "wps.cn": "WPS Office",
  "wps.com": "WPS Office",
};

function normalizedDomain(domain) {
  return String(domain || "").toLowerCase().replace(/^\.+/, "");
}

function prettyName(raw) {
  let r = String(raw || "").trim();
  r = r.replace(/^https?:\/\//, "");
  r = r.split(/[/?#]/)[0];
  r = r.replace(/^www\./, "");
  const base = r.split(".")[0];
  return base
    .split("-")
    .map((w) => (w ? w.charAt(0).toUpperCase() + w.slice(1) : w))
    .join(" ");
}

function appLabel(s) {
  const dom = normalizedDomain(s.domain);
  const r = remoteMeta(s.domain);
  if (r && r.name) return r.name;
  if (NAMES_MAP[dom]) return NAMES_MAP[dom];
  const match = Object.keys(NAMES_MAP).find((key) => dom.endsWith("." + key));
  if (match) return NAMES_MAP[match];
  return prettyName(s.name || s.domain);
}

function renderPills(entries) {
  catEl.innerHTML = "";
  const present = CATEGORY_ORDER.filter((c) =>
    c === "Semua" ? entries.length : entries.some((e) => categoryOf(e.domain) === c)
  );
  if (!present.length) return;
  present.forEach((c) => {
    const b = document.createElement("button");
    b.className = "cat";
    b.type = "button";
    b.textContent = c;
    if (c === activeCat) b.classList.add("on");
    b.addEventListener("click", () => {
      if (activeCat === c) return;
      activeCat = c;
      renderList(currentSites);
    });
    catEl.appendChild(b);
  });
}

function renderGrid(entries) {
  gridEl.innerHTML = "";
  if (!entries.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Belum ada app di kategori ini.";
    gridEl.appendChild(empty);
    return;
  }
  for (const s of entries) {
    const wrap = document.createElement("div");
    wrap.className = "tile-wrap";

    const tile = document.createElement("button");
    tile.className = "app-tile";
    tile.type = "button";
    tile.title = s.domain;
    const ic = document.createElement("span");
    ic.className = "tile-ic";
    buildIcon(ic, s.domain, appLabel(s));
    tile.appendChild(ic);
    const name = document.createElement("span");
    name.className = "app-name";
    name.textContent = appLabel(s);
    tile.appendChild(name);
    tile.addEventListener("click", () => injectAndOpen(s));
    wrap.appendChild(tile);

    if (isAdminAccount()) {
      const del = document.createElement("button");
      del.className = "app-del";
      del.type = "button";
      del.textContent = "Hapus";
      del.addEventListener("click", async (e) => {
        e.stopPropagation();
        if (!window.confirm("Hapus " + appLabel(s) + " dari daftar?")) return;
        try {
          await sitesRef().doc(s.id).delete();
          flash(appLabel(s) + " dihapus.");
        } catch (err) {
          flash("ERROR hapus: " + err.message);
        }
      });
      wrap.appendChild(del);
    }

    gridEl.appendChild(wrap);
  }
}

function renderList(sites) {
  currentSites = sites;
  latestDomains = Object.keys(sites);
  const removed = new Set(
    (remoteCatalog || []).filter((x) => x.deleted).map((x) => x.domain)
  );
  const entries = Object.keys(sites)
    .map((id) => ({ id, ...sites[id] }))
    .filter((e) => !removed.has(String(e.domain || "").toLowerCase().replace(/^\.+/, "")));

  if (!entries.length) {
    catEl.innerHTML = "";
    gridEl.innerHTML = "";
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Belum ada app di daftarmu.";
    gridEl.appendChild(empty);
    return;
  }

  renderPills(entries);

  const filtered =
    activeCat === "Semua" ? entries : entries.filter((e) => categoryOf(e.domain) === activeCat);
  renderGrid(filtered);
}

function startListener() {
  if (!initDb()) {
    flash("Firebase belum dikonfigurasi.");
    renderList({});
    return;
  }
  flash("Sinkron...");
  if (listener) listener();
  listener = sitesRef().onSnapshot(
    (snap) => {
      const sites = {};
      snap.forEach((d) => {
        sites[d.id] = d.data();
      });
      renderList(sites);
      chromeCall("storage.local.set", { [SITES_KEY]: Object.keys(sites) });
      flash(Object.keys(sites).length + " app tersedia (realtime).");
    },
    (err) => {
      console.error(err);
      flash("Gagal tersambung Firestore: " + err.message);
    }
  );
}

function enterApp() {
  if (!session) return;
  showMain();
  if (!initDb()) {
    flash("Firebase belum dikonfigurasi. Isi config.js dulu.");
    return;
  }
  loadCatalog().then(() => {
    renderList(currentSites);
  });
  loadExpiryCache().then(() => {
    showMain();
    updateLock();
    syncExpiry(true);
  });
  getActiveTab().then((tab) => {
    if (tab && tab.url && /^https?:\/\//.test(tab.url)) {
      const host = new URL(tab.url).hostname.replace(/^www\./, "");
      if (!nameInput.value) nameInput.value = host;
    }
  });
  startListener();
}

async function loginWithREST(email, password) {
  let res;
  try {
    res = await fetch(IDP_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    });
  } catch (e) {
    return { ok: false, error: "Gagal terhubung ke server, coba lagi." };
  }
  const data = await res.json();
  if (!res.ok || !data.idToken) {
    const msg = (data.error && data.error.message) || "";
    if (/INVALID_LOGIN_CREDENTIALS|EMAIL_NOT_FOUND|INVALID_PASSWORD|USER_NOT_FOUND/.test(msg)) {
      return { ok: false, error: "Email atau password salah." };
    }
    return { ok: false, error: "Login gagal, coba beberapa saat lagi." };
  }
  return {
    ok: true,
    idToken: data.idToken,
    email: data.email,
    uid: data.localId,
  };
}

async function onLoginSubmit(e) {
  e.preventDefault();
  const email = $("login-email").value.trim();
  const password = $("login-password").value;
  const errEl = $("login-error");
  errEl.textContent = "";

  if (!email || !password) {
    errEl.textContent = "Email dan password wajib diisi.";
    return;
  }

  const btn = $("login-submit");
  btn.disabled = true;
  btn.textContent = "Memproses…";

  const res = await loginWithREST(email, password);
  if (!res.ok) {
    errEl.textContent = res.error || "Login gagal.";
    btn.disabled = false;
    btn.textContent = "Masuk";
    return;
  }

  session = {
    idToken: res.idToken,
    email: res.email,
    uid: res.uid,
    isAdmin: email === ADMIN_EMAIL && password === ADMIN_PASSWORD,
  };
  await saveStoreSession(session);

  $("login-email").value = "";
  $("login-password").value = "";
  btn.disabled = false;
  btn.textContent = "Masuk";

  enterApp();
  flash("Halo, " + (email || "") + "!");
}

async function onLogout() {
  if (listener) {
    listener();
    listener = null;
  }
  await clearStoredSession();
  session = null;
  expiryCache = null;
  revoked = false;
  latestDomains = [];
  currentSites = {};
  activeCat = "Semua";
  await chromeCall("storage.local.remove", SITES_KEY);
  lockOverlay.hidden = true;
  showLogin();
}

/* ---------- init ---------- */

$("login-form").addEventListener("submit", onLoginSubmit);
$("logout-btn").addEventListener("click", onLogout);
$("pull-btn").addEventListener("click", pullFromTab);
const lockLogoutBtn = $("lock-logout");
if (lockLogoutBtn) lockLogoutBtn.addEventListener("click", onLogout);

document.addEventListener("DOMContentLoaded", () => {
  getStoredSession().then((stored) => {
    if (stored && stored.idToken) {
      session = stored;
      enterApp();
    } else {
      showLogin();
    }
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !session) return;
  if (changes[EXPIRY_KEY]) {
    loadExpiryCache().then(() => {
      showMain();
      renderExpiry();
      updateLock();
    });
  }
});
